#include <iostream>
#include <string>
#include <map>

using namespace std;

void printMap(map<string,int> m )
{
    map<string,int>::iterator its;

    for(its = m.begin(); its != m.end(); its++)
    {
        cout << its->first << ", " << its->second << endl;
    }
}


int main()
{
    map<string,int> age;

    age["Mark"] = 16;
    age["John"] = 15;
    age["Mary"] = 17;
    age["Jane"] = 16;
    age["Mark"] = 19;


    
    printMap(age);
    return 0;
}