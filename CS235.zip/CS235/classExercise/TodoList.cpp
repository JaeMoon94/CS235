#include "TodoList.h"

TodoList :: TodoList()
{
    cout << "TodoList Constructor" << endl;
}

TodoList :: ~TodoList()
{
    cout << "TodoList Deconstructor" << endl;
}

    /*
    *   Adds an item to the todo list with the data specified by the string "_duedate" and the task specified by "_task"
    */
    void TodoList::add(string _duedate, string _task)
    {
        cout <<  "Adding.." << endl;
    } 

    /*
    *   Removes an item from the todo list with the specified task name
    *
    *   Returns 1 if it removes an item, 0 otherwise
    */
    int TodoList::remove(string _task)
    {
        cout << "removing.." << endl;
        return 0;
    }

    /*
    *   Prints out the full todo list to the console
    */
    void TodoList::printTodoList()
    {
        cout << "Printing.." << endl;
    }
    
    /*
    *   Prints out all items of a todo list with a particular due date (specified by _duedate)
    */
    void TodoList::printDaysTasks(string _date) 
    {
        cout << "Printing day tasks.." << endl;
    }