#include <iostream>
#include <string>

#include "TodoList.h"

using namespace std;

int main(int argc, char *argv[]) {

    TodoList myList;
    
    if (argc > 1) {
        string command = argv[1];
        if (command == "add") {
            cout << "Trying to add something" << endl;
            if (argc > 3) {
            }
            else {
                cout << "Too few parameters for add" << endl;
            }
        }
        else if (command == "remove") {
            cout << "Trying to remove something" << endl;
            if (argc > 2) {
            }
            else {
                cout << "Too few parameters for remove" << endl;
            }
        }
        else if (command == "printList") {
            cout << "Print the whole TODO list" << endl;
        }
        else if (command == "printDay") {
            cout << "Print the TODO's for a particulate day" << endl;
            if (argc > 2) {
            }
            else {
                cout << "Too few parameters for printDay" << endl;
            }
        }
        else {
            cout << "Unknown command" << endl;
        }
    }
    else {
        cout << "Too few arguments" << endl;
    }

    return 0;
}