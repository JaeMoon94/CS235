#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "LinkedListInterface.h"
#include <iostream>
#include <string>
#include <stdexcept>  
#include <sstream>

template<typename T>

class LinkedList : public LinkedListInterface<T>
{
    private:
        struct Node
        {
            Node(T val)
            {
                value = val;
                next = NULL;
            }

            T value;
            Node *next;
        };
        Node *head;
    public:
        LinkedList(void)
        {
            head = NULL;
        }
        ~LinkedList(){
            clear();
        }


        /*
        insertHead

        A node with the given value should be inserted at the beginning of the list.

        Do not allow duplicate values in the list.
        */
	    void insertHead(T value)
        {
            if(!find(value))
            {
                Node *n = new Node(value);
                n -> next = head;
                head = n;
            }
        }

        /*
        insertTail

        A node with the given value should be inserted at the end of the list.

        Do not allow duplicate values in the list.
        */
        void insertTail(T value)
        {
            if(!find(value))
            {
                if(size() == 0)
                {
                    insertHead(value);
                    return;
                }
                else
                {
                    Node *temp = head;
                    while(temp ->next != NULL)
                    {
                        temp = temp->next;
                    }
                    if(temp -> next == NULL)
                    {
                        Node *n = new Node(value);
                        temp -> next = n;
                        n -> next = NULL;
                    }
                }
            }
        }

        /*
        insertAfter

        A node with the given value should be inserted immediately after the
        node whose value is equal to insertionNode.

        A node should only be added if the node whose value is equal to
        insertionNode is in the list. Do not allow duplicate values in the list.
        */
        void insertAfter(T value, T insertionNode)
        {
            if(find(value))
            {
                return;
            }

            Node *temp = head;
            while(temp != NULL)
            {
                if(temp -> value == insertionNode)
                {
                    Node *newNode = new Node(value);
                    newNode -> next = temp -> next;
                    temp->next = newNode;
                }
                temp = temp -> next;
            }
        }

        /*
        remove

        The node with the given value should be removed from the list.

        The list may or may not include a node with the given value.
        */
        void remove(T value)
        {
            if(size() == 0) return;
            Node *temp = head;
            Node *del = head;
            if(head->value == value)
            {
                Node* del = head;
                head = head ->next;
                delete del;
                return;
            }
            while(temp ->next != NULL)
            {
                if(temp->next->value == value)
                {
                    del = temp -> next;
                    temp->next = del -> next;
                    del -> next = NULL;
                    delete del;
                    return;
                }
                temp = temp->next;
            }

        }

        /*
        clear

        Remove all nodes from the list.
        */
        void clear()
        {
            while(head != NULL)
            {
                Node *n = head->next;
                delete head;
                head = n;
            }
        }

        /*
        at

        Returns the value of the node at the given index. The list begins at
        index 0.

        If the given index is out of range of the list, throw an out of range exception.
        */
        T at(int index)
        {
            if(index < 0 || index >= size())
            {
                throw std::out_of_range("");
            }
            Node *temp = head;
            int i = 0;
            while(temp != NULL)
            {
                if(i == index)
                {
                    return temp->value;
                }
                i++;
                temp = temp->next;
            }

            return NULL;
        }

        /*
        size

        Returns the number of nodes in the list.
        */
        int size()
        {
            int i = 0;
            Node *temp = head;
            while(temp != NULL)
            {
                temp = temp->next;
                i++;
            }
            return i;
        }

        /*
        toString
        
        Returns a string representation of the list, with the value of each node listed in order (Starting from the head) and separated by a single space
        There should be no trailing space at the end of the string

        For example, a LinkedList containing the value 1, 2, 3, 4, and 5 should return
        "1 2 3 4 5"
        */
        string toString()
        {
            stringstream str;

            Node *temp = head;
            while(temp != NULL)
            {
                if(temp -> next == NULL)
                {
                    str << temp->value;
                }
                else str << temp->value << " ";

                temp = temp -> next;

            }
            return str.str();
        }



        /* helper Method*/
        bool find(T val) 
        {
            Node *temp = head;
            while (temp != NULL) 
            {
                if (temp->value == val)
                    return true;
                temp = temp->next;
            }

        return false;
        }



};

#endif