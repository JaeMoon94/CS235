#include <map>
#include <vector>
#include <iostream>
#include <string>
#include <iterator>

using namespace std;
int main()
{
    map<string, int> my_map;
    vector<string> words;
    words.push_back("a");
    words.push_back("b");
    words.push_back("c");
    words.push_back("a");
    words.push_back("c");
    words.push_back("b");
    words.push_back("d");
    words.push_back("c");
    words.push_back("b");
    words.push_back("d");
    words.push_back("b");
    words.push_back("b");

    for(string word: words)
    {       
    if(my_map.count(word) > 0)
        my_map.at(word) = my_map.at(word)+1;
    else
        my_map.insert(pair<string, int> (word, 1));
    }
    
    map<string, int>::iterator it;
    
    for(it = my_map.begin(); it != my_map.end(); it++)
    {
        cout << it->first << " => " << it->second << endl;
    }
        

return 0;
}